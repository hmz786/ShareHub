package com.dahamada.chezbio.chezbio.repos;

import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UtilisateurRepository extends CrudRepository<Utilisateur, Integer> {

    @Query("SELECT u FROM Utilisateur u WHERE u.email = :email")
    //@Param est utilisé pour lier le paramètre method au paramètre Query.
    public Utilisateur getUtilisateurByEmail(@Param("email") String email);
    //Cette méthode suit la convention spécifié par Spring Data JPA
    public Long countById(Integer id);
    // 2 pour le 2 eme parametre active et 1 pour le 1er param`tre id
    @Query("UPDATE Utilisateur u SET u.active = ?2 WHERE u.id = ?1")
    // Comme c'est une méthode mis à jour on doit utiliser l'annotation @Modifying
    @Modifying
    public void updateActiveStatus(Integer id, boolean active);
    //Le 1 est l'argument pour premier paramètre qui est le mot clé
    @Query("SELECT u FROM Utilisateur u WHERE u.nom  LIKE %?1% OR u.prenom  LIKE %?1%")
    public List<Utilisateur> findAll(String keyword);

    /**
     * Récupère la liste des utilisateurs ayant le rôle spécifié.
     * Cette méthode utilise une requête JPQL pour sélectionner les utilisateurs en fonction du nom du rôle.
     *
     * @param nom Le nom du rôle pour filtrer les utilisateurs.
     * @return La liste des utilisateurs ayant le rôle spécifié.
     */


    @Query("SELECT u FROM Utilisateur u JOIN u.roles r WHERE r.nom = :nom")
    public List<Utilisateur> getUtilisateurByRoles(@Param("nom") String nom);

}
