package com.dahamada.chezbio.chezbio.service;

import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.entities.Role;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import com.dahamada.chezbio.chezbio.repos.RoleRepository;
import com.dahamada.chezbio.chezbio.repos.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.NoSuchElementException;

@Service
/*
Une transaction est définie par un début et une fin qui peut être soit
 une validation des modifications (commit),
soit une annulation des modifications effectuées (rollback).
La plupart des applications utilisent une gestion de transaction dans l’interaction avec
 un SGBDR (puisque ce dernier fournit le moteur de transaction)
Une gestion globale est utile lorsqu’une application interagit
 avec plusieurs systèmes transactionnels.
 Cela peut, par exemple, survenir si une application utilise
  simultanément plusieurs schémas de base de données et doit s’assurer
  de la cohérence des échanges. La gestion globale permet d’orchestrer
  les interactions entre les différents systèmes. Par exemple,
  si on annule la transaction avec un rollback alors
la transaction est annulée simultanément dans les différents systèmes transactionnels.
 */

@Transactional
public class UtilisateurService {
    public static final int USERS_PER_PAGE = 4;
    @Autowired
    private UtilisateurRepository repo;
    @Autowired
    private RoleRepository roleRepo;


    public List<Utilisateur> listAll() {
        return (List<Utilisateur>) repo.findAll();
    }

    public Utilisateur save(Utilisateur utilisateur) {
        System.out.println(" utilisateur service : " + repo.save(utilisateur));
        return repo.save(utilisateur);
    }

    public List<Role> listRoles() {
        return (List<Role>) roleRepo.findAll();
    }

    public boolean isEmailUnique(String email, Integer id) {
        //On cherche un utilisateur à partir de son email
        Utilisateur userByEmail = repo.getUtilisateurByEmail(email);
        //On vérifie l'unicité de l'email
        // quand on crée un nouveau utilisateur
        // S'il l'utilisateur n'existe pas déjà dans la bd avec l'email passé en paramètre
        // cela suppose que l'email n'existe pas
        // Autrement dit la méthode retourne true alors, l'email est unique parce que
        // l'utilisateur est null
        if (userByEmail == null) return true;

        //  return userByEmail == null; possibilité
        // sinon qu'existe un utilisateur avec le même email

        //Si l' id utilisateur est null, il n'existe pas, isCreatingNew = true sinon false
        boolean isCreatingNewUser = false;
        if (id == null) {
            isCreatingNewUser = true;
        }
        //Si l' id utilisateur n'existe pas mais l' email existe,
        //on retourne false car pas email unique, on ne peut pas creer un nouveau utilisateur
        //dans le mode de création utilisateur
        if (isCreatingNewUser) {
            //mais l'email existe, on retourne false car pas unique email
            if (userByEmail != null) return false;
        } else {
            //dans le mode d'edition utilisateur
            //Si l'id existe mais l'id qu'on edite  est différent de celui
            //de l'utilisateur possedant l'email,
            //on retourne false, car on ne peut pas creer un nouveau , puisqu email existe
            if (userByEmail.getId() != id) {
                return false;
            }
        }
        //dans tous les cas on peut creer, editer
        return true;

    }

    public Utilisateur get(Integer id) throws UtilisateurNotFoundException {
        try {
            return repo.findById(id).get();
        } catch (NoSuchElementException exception) {
            throw new UtilisateurNotFoundException("On ne peut pas trouver un utilisateur avec l'id" + id);
        }

    }

    public void delete(Integer id) throws UtilisateurNotFoundException {
        Long countById = repo.countById(id);
        //pas d'utilisateur dans la bd
        if (countById == null || countById == 0) {
            throw new UtilisateurNotFoundException("On ne peut pas trouver un utilisateur avec l'id" + id);
        }

        repo.deleteById(id);
    }


    public void updateActiveStatus(Integer id, boolean enabled) {
        repo.updateActiveStatus(id, enabled);
    }

    public List<Utilisateur> rechercherUtilisateur(String keyword) {

        if (keyword != null) {
            return repo.findAll(keyword);
        }

       return  null;
    }


    public Utilisateur getUtilisateurByEmail( String email){
        Utilisateur userByEmail = repo.getUtilisateurByEmail(email);
        return userByEmail;
    };



    public List<Utilisateur> listUtilisateursParRole(String nom) {
        return (List<Utilisateur>)
                repo.getUtilisateurByRoles(nom);
    }
    public Role getRole(String nom){
      return  roleRepo.findByNom(nom);
    }

}
