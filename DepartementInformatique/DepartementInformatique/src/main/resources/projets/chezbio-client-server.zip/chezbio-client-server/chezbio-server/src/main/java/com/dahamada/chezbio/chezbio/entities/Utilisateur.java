package com.dahamada.chezbio.chezbio.entities;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "utilisateurs")
public class Utilisateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(length = 128, nullable = false, unique = true)
    private String email;
    @Column(length = 64, nullable = false)
    private String password;
    @Column(length = 64, nullable = false)
    private String nom;
    @Column(length = 64, nullable = false)
    private String prenom;
    @Column(length = 64)
    private String photo;
    private boolean active;
    // Définit une relation Many-to-Many entre les entités Utilisateur et Role.
// FetchType.EAGER indique que les données relatives à cette relation doivent être chargées dès que l'entité Utilisateur est récupérée.
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            // Spécifie le nom de la table de jointure qui connecte les tables utilisateurs et roles.
            name = "utilisateurs_roles",
            // Spécifie la colonne dans la table utilisateurs_roles qui fait référence à la table utilisateurs.
            joinColumns = @JoinColumn(name = "utilisateur_id"),
            // Spécifie la colonne dans la table utilisateurs_roles qui fait référence à la table roles.
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )

    private Set<Role> roles = new HashSet<>();

    public Utilisateur() {
    }

    public Utilisateur( String nom, String prenom,String email, String password) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.password = password;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
    public void ajouter(Role role){
        this.roles.add(role);
    }

    @Override
    public String toString() {
        return "Utilisateur{" + "id=" + id + ", email=" + email + ", password=" + password + ", nom=" + nom + ", prenom=" + prenom + ", roles=" + roles + '}';
    }
}
