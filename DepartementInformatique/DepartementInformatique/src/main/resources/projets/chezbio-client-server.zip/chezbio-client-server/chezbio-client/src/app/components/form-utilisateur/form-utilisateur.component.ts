import { Component } from '@angular/core';
import { Utilisateur } from '../../models/utilisateur.model';
import { UtilisateurService } from '../../services/utilisateur.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormGroup, FormsModule, NgForm, Validators } from '@angular/forms';
import { Role } from '../../models/role.model';
import {tap} from "rxjs";

@Component({
  selector: 'app-form-utilisateur',
  templateUrl: './form-utilisateur.component.html',
  styleUrl: './form-utilisateur.component.css'

})
export class FormUtilisateurComponent {

    // Instance d'utilisateur pour le formulaire
    utilisateur: Utilisateur = new Utilisateur();

    // Variable pour indiquer si le formulaire est en mode édition
    editing = false;
  selectedRoles: any;

    // Constructeur du composant, injecte les services et les dépendances nécessaires
    constructor(
      private utilisateurService: UtilisateurService,
      public router: Router,
      activeRoute: ActivatedRoute
    ) {
      // Abonnement aux changements dans les paramètres de l'URL
      activeRoute.params.subscribe(params => {
        // Vérifie si le mode est 'edit'
        this.editing = params['mode'] == 'edit';
        // Récupère l'ID depuis les paramètres de l'URL
        let id = params['id'];
        if (id != null) {
          console.log("id " + id);
          console.log("this.utilisateur.nom : " + this.utilisateur?.nom);
          console.log("utilisateurService.getUtilisateur(id) : " + utilisateurService.getUtilisateur(id))
          // Copie les données de l'utilisateur trouvé ou crée un nouvel utilisateur
          Object.assign(this.utilisateur, utilisateurService.getUtilisateur(id) || new Utilisateur());
        }
      });
    }

    public roleSelectionnee: string | null = null; // Mise à jour du type de données pour éviter l'erreur
    get roles(): Role[] {
      const rolesMap = new Map<string, Role>(); // Utiliser une carte (Map) pour stocker les rôles uniques
      this.utilisateurService.getUtilisateurs(this.roleSelectionnee).forEach(utilisateur => {
        if (utilisateur.roles) {
          utilisateur.roles.forEach(role => {
            if (role.nom) {
              rolesMap.set(role.nom, role); // Utiliser le nom du rôle comme clé dans la carte
            }
          });
        }
      });
      return Array.from(rolesMap.values()); // Convertir les valeurs de la carte en tableau
    }





    // Méthode appelée lors de la soumission du formulaire
  /*
    submitForm(form: NgForm) {
      if (form.valid) {
        // Convertir les noms de rôles sélectionnés en objets Role
        const selectedRoles: Role[] = this.selectedRoles.map((roleName: any) => {
          return { nom: roleName }; // Crée un objet Role avec le nom du rôle
        });

        // Mettre à jour les rôles de l'utilisateur avec les objets Role sélectionnés
        this.utilisateur.roles = selectedRoles;

        // Appeler la méthode du repository pour sauvegarder l'utilisateur
        this.utilisateurService.saveUtilisateur(this.utilisateur).subscribe(
          utilisateur => {
            console.log("Utilisateur enregistré avec succès:", utilisateur);
            // Naviguer vers la page des utilisateurs une fois que l'enregistrement est réussi
            this.router.navigateByUrl('/utilisateur');
          },
          error => {
            console.error("Erreur lors de l'enregistrement de l'utilisateur:", error);
            // Traiter l'erreur si nécessaire
          }
        );
      }
    }
 */

  submitForm(form: NgForm) {
    if (form.valid) {
      // Convertir les noms de rôles sélectionnés en objets Role
      const selectedRoles: Role[] = this.selectedRoles.map((roleName: any) => {
        return { nom: roleName }; // Crée un objet Role avec le nom du rôle
      });

      // Mettre à jour les rôles de l'utilisateur avec les objets Role sélectionnés
      this.utilisateur.roles = selectedRoles;

      // Appeler la méthode du repository pour sauvegarder l'utilisateur
      this.utilisateurService.saveUtilisateur(this.utilisateur)
        .pipe(
          tap(utilisateur => {
            console.log("Utilisateur enregistré avec succès:", utilisateur);
            // Naviguer vers la page des utilisateurs une fois que l'enregistrement est réussi
            this.router.navigateByUrl('/utilisateur');
          })
        )
        .subscribe({
          error: error => {
            console.error("Erreur lors de l'enregistrement de l'utilisateur:", error);
            // Traiter l'erreur si nécessaire
          }
        });
    }
  }


    // Méthode pour réinitialiser le formulaire en créant un nouvel utilisateur
    resetForm() {
      this.utilisateur = new Utilisateur();
    }
    // Méthode appelée lors du changement de fichier dans l'input de type file
    onFileChange(event: any): void {
      const reader = new FileReader();

      if (event.target.files && event.target.files.length) {
        const file = event.target.files[0];

        // Lit le contenu du fichier en tant que Data URL et le met dans la propriété 'photo' de l'utilisateur
        reader.onload = () => {
          this.utilisateur.photo = reader.result as string;
        };

        reader.readAsDataURL(file);
      }
    }

    //utilisateurForme ="";
    // un formulaire réactif avec des champs et des validateurs
    // Déclaration du formulaire réactif
    form: FormGroup = new FormGroup({
      nom: new FormControl(''),
      prenom: new FormControl(''),
      email: new FormControl(''),
      password: new FormControl(''),
      confirmPassword: new FormControl(''),
      acceptTerms: new FormControl(false),
    });
    // Initialisation du formulaire dans le hook ngOnInit
    ngOnInit(): void {
      this.form = new FormGroup({
        // Contrôle pour le champ email avec validation requise et format d'email
        email: new FormControl(this.utilisateur.email, [
          Validators.required,
          Validators.email
        ]),
        // Contrôle pour le champ nom avec validation requise, longueur minimale et motif spécifique
        nom: new FormControl(this.utilisateur.nom, [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('^[A-Za-z ]+$')
        ]),
        // Contrôle pour le champ prénom avec validation requise, longueur minimale et motif spécifique
        prenom: new FormControl(this.utilisateur.prenom, [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('^[A-Za-z ]+$')
        ]),
        // Contrôle pour le champ mot de passe avec validation requise, longueur minimale et motif spécifique
        password: new FormControl(this.utilisateur.password, [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')
        ]),
        // Contrôle pour le champ rôle avec validation requise
        role: new FormControl(this.utilisateur.active, Validators.required),
        // Contrôle pour le champ disponible
        active: new FormControl(this.utilisateur.active)
      });
    }
    // Méthodes pour obtenir des références aux champs du formulaire
    get email() { return this.form.get('email'); }
    get nom() { return this.form.get('nom'); }
    get prenom() { return this.form.get('prenom'); }
    get password() { return this.form.get('password'); }
    get role() { return this.form.get('role'); }
    get active() { return this.form.get('active'); }
}
