package com.dahamada.chezbio.chezbio.service;

import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.repos.ProduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class ProduitService {
    @Autowired
    private ProduitRepository repo;

    public List<Produit> listAll() {
        return (List<Produit>) repo.findAll();
    }

    public Produit save(Produit produit) {

        produit.setDerniere_maj(new Date());

        return repo.save(produit);
    }

    public Produit findById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public String verifierProduitUnique(String nom) {

        Produit produitByNom = repo.findByNom(nom);

        if (produitByNom != null) {
            return "Doublon";
        } else {
            return "OK";
        }

    }

    public List<Produit> listProduitsParCategorie( String nom) {
        return (List<Produit>)
                repo.getProduitsByCategorie(nom);
    }
}
