package com.dahamada.chezbio.chezbio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChezbioApplicationTests {

    @Test
    void contextLoads() {
    }

}
