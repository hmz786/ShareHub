package com.dahamada.chezbio.chezbio.entities;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;
import java.util.Date;
@Entity
@Table(name = "produit")
public class Produit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id ;
    @Column(name = "nom", length = 45, nullable = false, unique = true)
    private String nom ;
    //  private BigDecimal  prix;
    private double  prix;
    private String description ;
    @Column(length = 64)
    private String url_photo;
    @Column(name = "derniere_maj")
    @Temporal(TemporalType.DATE)
    private Date derniere_maj ;

  // Définit une relation Many-to-One entre cette entité et l'entité Categorie.
// "optional = false" indique que la relation est obligatoire, c'est-à-dire que
// chaque instance de cette entité doit être associée à une catégorie.
  @ManyToOne(optional = false)
// Spécifie la colonne dans cette entité (Produit) qui fait référence à la table Categorie.
// "name = "categorie_id"" indique le nom de la colonne dans la table Produit
// qui stockera l'identifiant de la catégorie.
// "nullable = false" indique que cette colonne ne peut pas être nulle dans la base de données.
  @JoinColumn(name = "categorie_id", nullable = false)
// Champ qui représente la catégorie à laquelle appartient ce produit.
  private Categorie categorie;


    public Produit() {
    }

    public Produit(long id) {
        this.id = id;
    }

    public Produit(String nom, double prix, String description, String urlPhoto, Date derniere_maj) {
        this.nom = nom;
        this.prix = prix;
        this.description = description;
        this.url_photo = urlPhoto;
        this.derniere_maj = derniere_maj;

        // listeproduitCommande = new ArrayList();
    }

    public Produit(String nom, double prix, String description, String url_photo, Date derniere_maj, Categorie categorie) {

        this.nom = nom;
        this.prix = prix;
        this.description = description;
        this.url_photo = url_photo;
        this.derniere_maj = derniere_maj;
        this.categorie = categorie;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl_photo() {
        return url_photo;
    }

    public void setUrl_photo(String url_photo) {
        this.url_photo = url_photo;
    }

    public Date getDerniere_maj() {
        return derniere_maj;
    }

    public void setDerniere_maj(Date derniere_maj) {
        this.derniere_maj = derniere_maj;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }


    @Override
    public String toString() {
        return "Produit{" + "id=" + id + ", nom=" + nom + ", prix=" + prix + ", description=" + description + ", url_photo=" + url_photo + ", derniere_maj=" + derniere_maj + ", categorie=" + categorie + '}';
    }

}
