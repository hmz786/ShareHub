import { Role } from "./role.model";

export class Utilisateur {
    constructor(public id?:number,public email?:string, 
        public nom?:string,public prenom?:string,
        public password?:string,public photo?:string, 
        public active:boolean=false, 
        public roles: Role[]=[]){}
}
