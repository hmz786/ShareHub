package com.dahamada.chezbio.chezbio.repos;

import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.entities.Role;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends CrudRepository<Role, Integer> {
    public Role findByNom(String nom);
}
