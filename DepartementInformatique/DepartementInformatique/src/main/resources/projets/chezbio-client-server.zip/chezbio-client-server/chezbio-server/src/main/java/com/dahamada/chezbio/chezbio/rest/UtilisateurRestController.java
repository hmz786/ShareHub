package com.dahamada.chezbio.chezbio.rest;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Role;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import com.dahamada.chezbio.chezbio.repos.UtilisateurRepository;
import com.dahamada.chezbio.chezbio.service.UtilisateurService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.*;

@RestController
@RequestMapping("/api") // Spécifie le chemin de base pour toutes les requêtes de cette classe

public class UtilisateurRestController {

    @Autowired
    UtilisateurService service;

    @Autowired
    UtilisateurRepository repos;

    @Autowired
    private EntityManager entityManager; // Injection de dépendance de l'EntityManager

    @PostMapping("/utilisateurs/check_email")
    public String verifierDoublonEmail(@RequestParam("email") String email, @RequestParam("id") Integer id) {
        // Pour la simplicité on retourne pas un Objet JSON mais plutôt une chaîne de caractères
        // Selon la valeur que retourne la méthode isEmailUnique
        return service.isEmailUnique(email, id) ? "OK" : "Doublon";
    }

    // version 1
   /*
    @GetMapping("/utilisateurs")
  public ResponseEntity<List<Utilisateur>> getAllUtilisateurs(){
        List<Utilisateur> utilisateurs = new ArrayList<>();
    List<Utilisateur>  allUsers =  service.listAll();
          for(Utilisateur utilisateur :allUsers){
              utilisateurs.add(utilisateur);
          }
        return  new ResponseEntity<>(utilisateurs, HttpStatus.OK);
  }
  */

  // version 2
  /*
    @GetMapping("/utilisateurs")
    public ResponseEntity<List<Utilisateur>> getAllUtilisateurs(){
        List<Utilisateur> utilisateurs = new ArrayList<>();
          service.listAll().forEach(utilisateurs::add);

        return  new ResponseEntity<>(utilisateurs, HttpStatus.OK);
    }
*/
    // version 3

    /*
    @GetMapping("/utilisateurs")
    public ResponseEntity<List<Utilisateur>> getAllUtilisateurs(){
        List<Utilisateur> utilisateurs = new ArrayList<>();
        service.listAll().forEach(utilisateur ->utilisateurs.add(utilisateur));

        return  new ResponseEntity<>(utilisateurs, HttpStatus.OK);
    }
*/
    // version 3
    /*
    @GetMapping("/utilisateurs")
    public ResponseEntity<List<Utilisateur>> getAllUtilisateurs(@RequestParam(required = false) String role){
        List<Utilisateur> utilisateurs = new ArrayList<>();
        if(role == null){
            service.listAll().forEach(utilisateurs::add);
        }else{
            service.listUtilisateursParRole(role).forEach(utilisateurs::add);
        }
        return  new ResponseEntity<>(utilisateurs, HttpStatus.OK);
    }
    */

    @GetMapping("/utilisateurs")
    public ResponseEntity<List<Utilisateur>> getAllUtilisateurs(@RequestParam(required = false) String role){
        try {
            List<Utilisateur> utilisateurs = new ArrayList<>();
            if(role == null){
                service.listAll().forEach(utilisateurs::add);
            }else{
                service.listUtilisateursParRole(role).forEach(utilisateurs::add);
            }
            if(utilisateurs.isEmpty()){
                return  new ResponseEntity<>(utilisateurs, HttpStatus.NO_CONTENT);
            }

            return  new ResponseEntity<>(utilisateurs, HttpStatus.OK);

        }catch (Exception e){
            return  new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
    /*
    @PostMapping("/utilisateurs")
    public ResponseEntity<Utilisateur> createUtilisateur(@RequestBody Utilisateur utilisateur) {
        try {
            if (utilisateur.getRoles() == null || utilisateur.getRoles().isEmpty()) {
                // Si aucun rôle n'est sélectionné, retournez une réponse avec un code de statut BAD_REQUEST
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }

            // Récupérez le premier rôle de la liste des rôles de l'utilisateur
            Role role = utilisateur.getRoles().iterator().next();
               System.out.println(" role.getNom() : " +role.getNom());
            // Assurez-vous que le rôle récupéré existe dans la base de données
            role = service.getRole(role.getNom());
            if (role != null) {
                // Ajoutez le rôle à l'utilisateur
                //  userKarim : Utilisateur{id=null, email=karim10@gmail.com, password=karim123, nom=Alain, prenom=Karim, roles=[Admin]}
                System.out.println(" role : " +role);
                utilisateur.ajouter(role);
            } else {
                // Si le rôle n'existe pas, retournez une réponse avec un code de statut BAD_REQUEST
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }

            // Enregistrez l'utilisateur dans la base de données
            System.out.println(" utilisateur : " + utilisateur);
            service.save(utilisateur);

            // Une fois que l'utilisateur est enregistré, retournez l'utilisateur avec le code de statut CREATED
            return new ResponseEntity<>(utilisateur, HttpStatus.CREATED);
        } catch (Exception e) {
            // En cas d'erreur, retournez une réponse avec un code de statut INTERNAL_SERVER_ERROR
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
*/
    @PostMapping("/utilisateurs")
    public ResponseEntity<Utilisateur> createUtilisateur(@RequestBody Utilisateur utilisateur) {
        try {
            if (utilisateur.getRoles() == null || utilisateur.getRoles().isEmpty()) {
                // Si aucun rôle n'est sélectionné, retournez une réponse avec un code de statut BAD_REQUEST
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }

            // Créez un ensemble de rôles uniques à partir des rôles de l'utilisateur
            int roleId=0;
            Set<Role> uniqueRoles = new HashSet<>();
            for (Role role : utilisateur.getRoles()) {

                switch (role.getNom()){
                    case "Admin" : roleId =1;
                        break;
                    case "Vendeur" : roleId =2;
                        break;
                    case "Editeur" : roleId =3;
                        break;
                    case "Expéditeur" : roleId =4;
                        break;
                    case "Assistant" : roleId =5;
                        break;
                    default: roleId= 6;
                        break;
                }
                System.out.println(" role.getId() " + roleId);
                uniqueRoles.add(entityManager.find(Role.class, roleId));
            }
           System.out.println(" uniqueRoles :" + uniqueRoles);
            // Réinitialisez les rôles de l'utilisateur avec les rôles uniques
          //  utilisateur.setRoles((Set<Role>) new ArrayList<>(uniqueRoles));
          //  utilisateur.setRoles(new ArrayList<>(uniqueRoles));

            utilisateur.setRoles(new HashSet<>(uniqueRoles));

            System.out.println(" utilisateur :" + utilisateur);
            // Enregistrez l'utilisateur dans la base de données
            service.save(utilisateur);

            // Une fois que l'utilisateur est enregistré, retournez l'utilisateur avec le code de statut CREATED
            return new ResponseEntity<>(utilisateur, HttpStatus.CREATED);
        } catch (Exception e) {
            // En cas d'erreur, retournez une réponse avec un code de statut INTERNAL_SERVER_ERROR
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PutMapping("/utilisateurs/{id}")
    public ResponseEntity<Utilisateur> updateUtilisateur(@PathVariable ("id") int id, @RequestBody Utilisateur utilisateur){
           Optional<Utilisateur> utilisateurOption = repos.findById(id);
           if(utilisateurOption.isPresent()){
             Utilisateur _utilisateur =  utilisateurOption.get();
               _utilisateur.setNom(utilisateur.getNom());
               _utilisateur.setPrenom(utilisateur.getPrenom());
               _utilisateur.setPassword(utilisateur.getPassword());
               _utilisateur.setPhoto(utilisateur.getPhoto());
               _utilisateur.setActive(utilisateur.isActive());
               return  new ResponseEntity<>(service.save(_utilisateur), HttpStatus.OK);
           }else{

               return  new ResponseEntity<>(HttpStatus.NOT_FOUND);
           }

}
    @PostMapping("/utilisateurs/{id}/status")
    public ResponseEntity<HttpStatus> updateActiveStatus(@PathVariable("id") int id, @RequestParam("active") boolean active) {
        try {
            // Validation de l'ID de l'utilisateur
            if (!repos.existsById(id)) {
                // Log message si l'ID de l'utilisateur n'existe pas
                System.out.println(" L'ID de l'utilisateur n'existe pas: " + id);
                return ResponseEntity.notFound().build();
            }

            // Mise à jour du statut actif de l'utilisateur
            service.updateActiveStatus(id, active);

            // Log message si la mise à jour du statut est réussie
            System.out.println("Statut actif de l'utilisateur avec l'ID " + id + " mis à jour avec succès : " + active);

            // Réponse en cas de succès
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            // Log message en cas d'erreur
            System.out.println("Erreur lors de la mise à jour du statut actif de l'utilisateur avec l'ID : " + id);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
@DeleteMapping("utilisateurs/{id}")
    public ResponseEntity<HttpStatus> deleteUtilisateur(@PathVariable ("id") int id){
    repos.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
}
@GetMapping("utilisateurs/id/{id}")
    public ResponseEntity<Utilisateur> findUtilisateur(@PathVariable ("id") int id){
        Optional<Utilisateur> utilisateurOptional = repos.findById(id);
        if(utilisateurOptional.isPresent()){
            Utilisateur utilisateur = utilisateurOptional.get();
            return  ResponseEntity.ok(utilisateur);
        }else{
           return  ResponseEntity.notFound().build();
        }
    }
}

