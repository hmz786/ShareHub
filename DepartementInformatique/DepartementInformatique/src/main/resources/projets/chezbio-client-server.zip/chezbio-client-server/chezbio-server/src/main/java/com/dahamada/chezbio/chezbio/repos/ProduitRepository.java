package com.dahamada.chezbio.chezbio.repos;

import com.dahamada.chezbio.chezbio.entities.Produit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProduitRepository extends JpaRepository<Produit, Long> {
    public Produit findByNom(String nom);
    @Query("SELECT prod FROM Produit prod WHERE prod.categorie.nom =:nom")
    public List<Produit> getProduitsByCategorie(@Param("nom") String nom);
}
