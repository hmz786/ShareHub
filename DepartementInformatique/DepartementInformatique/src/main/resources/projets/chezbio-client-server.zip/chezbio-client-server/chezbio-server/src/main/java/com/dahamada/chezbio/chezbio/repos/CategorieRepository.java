package com.dahamada.chezbio.chezbio.repos;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategorieRepository extends JpaRepository<Categorie, Integer> {
}
