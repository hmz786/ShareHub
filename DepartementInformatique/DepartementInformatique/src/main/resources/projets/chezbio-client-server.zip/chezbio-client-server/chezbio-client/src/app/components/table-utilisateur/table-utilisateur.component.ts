import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Utilisateur } from '../../models/utilisateur.model';
import { UtilisateurService } from '../../services/utilisateur.service';
import { UtilisateurRepository } from '../../repository/utilisateur.repository';

@Component({
  selector: 'app-table-utilisateur',
  templateUrl: './table-utilisateur.component.html',
  styleUrl: './table-utilisateur.component.css'
})
export class TableUtilisateurComponent {

   // @Input: Propriété permettant au parent de passer des données à l'enfant
   @Input() utilisateurs: Utilisateur[] = [];

   // @Output: Événement émis lors de la suppression d'un utilisateur
  @Output() deleteUtilisateurEvent = new EventEmitter<number>();

  constructor(private repository: UtilisateurRepository) {}
    // @Output: Méthode appelée lors de la suppression d'un utilisateur
  deleteUtilisateur(id: number | undefined) {
    // Logique de suppression si nécessaire

    // Émettre l'événement de suppression
    this.deleteUtilisateurEvent.emit(id || 0); // Utilisation de 0 si id est undefined
  }

  /*
  Dans cette méthode getClassForUser, nous parcourons les rôles de l'utilisateur 
  pour vérifier s'il a un rôle spécifique, comme administrateur (Admin) 
  ou éditeur (Editeur).
   En fonction du rôle trouvé, nous retournons 
   la classe CSS appropriée (bg-primary pour administrateur 
    et bg-secondary pour éditeur). Si aucun rôle spécifique n'est trouvé,
     nous retournons une chaîne vide, ce qui signifie qu'aucune 
     classe CSS spécifique n'est appliquée.

  */

  getClassForUser(utilisateur: Utilisateur): string {
    if (utilisateur.roles) {
      // Vérifie si l'utilisateur a le rôle d'administrateur
      if (utilisateur.roles.some(role => role.nom === 'Admin')) {
        return 'bg-primary';
      }
      // Vérifie si l'utilisateur a le rôle d'éditeur
      else if (utilisateur.roles.some(role => role.nom === 'Editeur')) {
        return 'bg-secondary';
      }
    }
    // Retourne une chaîne vide si aucun rôle spécifique n'est trouvé
    return '';
  }

  updateStatus(id: number | undefined, active: boolean) {
    this.repository.updateStatus(id, active).subscribe(
      (updatedUser: Utilisateur) => { // Spécification explicite du type
        console.log('Statut de disponibilité mis à jour avec succès : ', updatedUser);
        // Effectuez ici d'autres opérations si nécessaire après la mise à jour du statut
      },
      (error: any) => { // Spécification explicite du type
        console.error('Erreur lors de la mise à jour du statut de disponibilité : ', error);
        // Traitez l'erreur ici ou affichez un message à l'utilisateur
      }
    );
  }
}
