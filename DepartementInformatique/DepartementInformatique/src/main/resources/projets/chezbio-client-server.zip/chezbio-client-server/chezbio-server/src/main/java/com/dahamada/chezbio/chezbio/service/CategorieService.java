package com.dahamada.chezbio.chezbio.service;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.repos.CategorieRepository;
import com.dahamada.chezbio.chezbio.repos.ProduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class CategorieService {
    @Autowired
    private CategorieRepository repo;
    @Autowired
    private ProduitRepository repopro;

    public List<Categorie> listAll() {
        return (List<Categorie>) repo.findAll();
    }
    public Categorie save(Categorie categorie){
        return repo.save(categorie);
    }


    public List<Produit> listProduitByCategorie(Integer id) {
        List<Produit> listProduitByCategorie = new ArrayList<>();
        Categorie categorie = repo.findById(id).orElse(null);
        List<Produit>  listeProduit = repopro.findAll();
        for (Produit produit : listeProduit) {
            if(produit.getCategorie()==categorie){
                listProduitByCategorie.add(produit);
            }
        }

        return listProduitByCategorie;
    }
}
