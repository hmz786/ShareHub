import { Injectable } from '@angular/core';
import { Utilisateur } from '../models/utilisateur.model';
import { UtilisateurRepository } from '../repository/utilisateur.repository';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UtilisateurService {

  private utilisateurs: Utilisateur[] = []; // Tableau local d'utilisateurs
  private roles: string[] = []; // Tableau local des rôles

  constructor(private repository: UtilisateurRepository) {
    // Initialise le service en récupérant les données des utilisateurs à partir du repository
    repository.getUtilisateurs().subscribe((data) => {
      // Met à jour le tableau local d'utilisateurs avec les données reçues du service
      this.utilisateurs = data;
   
    // console.log("UtilisateurService  this.utilisateurs " + this.utilisateurs);
      // Extrait les rôles des utilisateurs pour construire le tableau des rôles
      this.roles = this.getRolesFromUtilisateurs(data);
    });
  }

  // Renvoie la liste des utilisateurs en filtrant par rôle (si spécifié)
  getUtilisateurs(role: string | null): Utilisateur[] {
    return this.utilisateurs.filter(
      // Filtre les utilisateurs en fonction du rôle spécifié
      (user) => role == null || user.roles?.some(r => r.nom === role)
    );
  }

  // Renvoie la liste des rôles
  getRoles(): string[] {
    return this.roles;
  }

  // Extrait les noms de rôles à partir de la liste des utilisateurs
  // pour construire un tableau de rôles uniques
  private getRolesFromUtilisateurs(utilisateurs: Utilisateur[]): string[] {
    const uniqueRolesSet = new Set<string>(); // Utilisation d'un ensemble pour stocker des valeurs uniques
    utilisateurs.forEach((utilisateur) => {
      if (utilisateur.roles && utilisateur.roles.length > 0) {
        // Si l'utilisateur a des rôles, ajoute chaque nom de rôle à l'ensemble
        utilisateur.roles.forEach(role => {
          if (role && role.nom) { // Vérifie si role est défini et si son nom est une chaîne de caractères
            uniqueRolesSet.add(role.nom);
          }
        });
      }
    });
    return Array.from(uniqueRolesSet).sort(); // Transforme l'ensemble en tableau et le trie par ordre alphabétique
  }
  
  
  // Renvoie un utilisateur par son ID
  getUtilisateur(id: number): Utilisateur | undefined {
    return this.utilisateurs.find(user => user?.id == id);
  }
 

      // Fonction de localisation utilisée pour trouver l'index d'un utilisateur par son ID
      private locator = (user: Utilisateur, id: number | undefined) => user.id ==id;
 
   // Méthode pour sauvegarder un utilisateur
   /*
   saveUtilisateur(utilisateur: Utilisateur) {
     if (utilisateur.id === 0 || utilisateur.id === null) {
       // Si l'ID est nul ou égal à 0, appelle le service pour sauvegarder le nouvel utilisateur
       this.repository.saveUtilisateur(utilisateur)
         .subscribe(user => this.utilisateurs.push(user));
     } else {
       // Sinon, appelle le service pour mettre à jour l'utilisateur existant
       this.repository.updateUtilisateur(utilisateur).subscribe(user => {
         // Trouve l'index de l'utilisateur dans le tableau local et le remplace par la nouvelle version
         const index = this.utilisateurs.findIndex(item => this.locator(item, user.id));
         // Utilise .splice pour remplacer l'élément à l'index donné par la nouvelle version de l'utilisateur
         this.utilisateurs.splice(index, 1, user);
       });
     } 
   }
   */

   saveUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {
    if (utilisateur.id === 0 || utilisateur.id === null ||  utilisateur.id === undefined) {
      // Si l'ID est nul ou égal à 0, appelle le service pour sauvegarder le nouvel utilisateur
      console.log("Utilisateur " + Utilisateur);
      return this.repository.saveUtilisateur(utilisateur);
    } else {
      console.log("utilisateur.id " + utilisateur?.id);
      console.log("utilisateur " + utilisateur?.nom);
      // Sinon, appelle le service pour mettre à jour l'utilisateur existant
      return this.repository.updateUtilisateur(utilisateur);
    } 
  }
  
    // Méthode pour supprimer un utilisateur par son ID
  deleteUtilisateur(id: number | undefined) {
    console.log('deleteUtilisateur called with ID:', id);
    this.repository.deleteUtilisateur(id).subscribe(() => {
      // Utilisation de '=>' (fonction fléchée) pour définir la fonction de suppression
      const index = this.utilisateurs.findIndex(user => this.locator(user, id));
      if (index > -1) {
        // Supprime l'utilisateur du tableau local
        this.utilisateurs.splice(index, 1);
      }
    });
  }

}
