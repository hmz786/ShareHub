import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Produit } from '../models/produit.model';

@Injectable({
  providedIn: 'root'  // @Injectable est un décorateur Angular utilisé pour indiquer que le service peut être injecté dans d'autres composants ou services.
  // providedIn: 'root' signifie que le service sera injecté au niveau de l'application (root).
})
/*
 La classe ProduitService se concentre spécifiquement
  sur les opérations liées à la gestion des utilisateurs 
  au niveau de l'API
*/
export class ProduitRepository {

  // URL de l'API pour les produits
 // private apiUrl = "http://localhost:3000/produits";
   private apiUrl = "http://localhost:8080/api/products";
  // Constructeur du service, injecte HttpClient
  // HttpClient est un service Angular qui permet d'effectuer des requêtes HTTP.
  constructor(private http: HttpClient) { }

  // Obtient la liste des produits de manière asynchrone
  // Observable est une classe du module rxjs qui représente une séquence d'événements asynchrones.
  // Dans ce contexte, il est utilisé pour gérer la réponse asynchrone de la requête HTTP.
  getProduits(): Observable<Produit[]> {
    return this.http.get<Produit[]>(this.apiUrl);
  }

  // Supprime un produit en envoyant une requête DELETE avec son ID
  deleteProduit(id: number | undefined): Observable<Produit> {
    return this.http.delete<Produit>(`${this.apiUrl}/${id}`);
  }

  // Sauvegarde un nouvel produit en envoyant une requête POST avec l'produit
  saveProduit(produit: Produit): Observable<Produit> {
    return this.http.post<Produit>(this.apiUrl, produit);
  }

  // Met à jour un produit en envoyant une requête PUT avec le produit et son ID
  updateProduit(produit: Produit): Observable<Produit> {
    return this.http.put<Produit>(`${this.apiUrl}/${produit.id}`, produit);
  }

  findByName(nom:any): Observable<Produit[]> {
    return this.http.get<Produit[]>(`${this.apiUrl}?nom=${nom}`);
  }
}
