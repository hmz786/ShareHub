package com.dahamada.chezbio.chezbio.rest;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.repos.ProduitRepository;
import com.dahamada.chezbio.chezbio.service.ProduitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
/*
Cette classe représente un contrôleur REST en Java Spring qui gère les requêtes relatives aux produits.
 Il utilise des annotations pour spécifier les chemins des différentes requêtes et les méthodes correspondantes
 */
@RestController // Indique que cette classe est un contrôleur REST
@RequestMapping("/api") // Spécifie le chemin de base pour toutes les requêtes de cette classe
public class ProduitRestController {
    @Autowired
    private ProduitService service; // Injection de dépendance du service ProduitService
    @Autowired
    private EntityManager entityManager; // Injection de dépendance de l'EntityManager
    @Autowired
    private ProduitRepository repo; // Injection de dépendance du repository ProduitRepository

@GetMapping("/products")
public ResponseEntity<List<Produit>> getAllProducts(@RequestParam(required = false) String categorie) {
    try {
        List<Produit> produits = new ArrayList<>();
        if (categorie == null) {
            List<Produit> allProducts = service.listAll();
            for (Produit produit : allProducts) {
                produits.add(produit);
            }
        } else {
            List<Produit> productsByCategory = service.listProduitsParCategorie(categorie);
            for (Produit produit : productsByCategory) {
                produits.add(produit);
            }
        }
        // Utilisation de ResponseEntity pour contrôler les détails de la réponse HTTP
        if (produits.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Retourne un code 204 NO_CONTENT si la liste est vide
        }
        return new ResponseEntity<>(produits, HttpStatus.OK); // Retourne la liste de produits avec un code 200 OK
    } catch (Exception e) {
        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); // Retourne un code 500 INTERNAL_SERVER_ERROR en cas d'erreur
    }
}



// 2eme version :
/*
Dans ce cas ici, l'action est spécifiée comme une référence de méthode produits::add,
 ce qui signifie que pour chaque élément de la liste retournée par le service,
 la méthode add de l'objet produits est appelée pour ajouter cet élément à la liste.

 Cela est possible car la méthode add est une méthode non statique d'une classe non statique,
  ce qui permet de l'utiliser dans une référence de méthode. 
  Cette syntaxe est une manière concise 
 et expressive de spécifier le comportement à appliquer 
 à chaque élément de la liste lors de l'itération.

*/

    /*
    @GetMapping("/products")
    public ResponseEntity<List<Produit>> getAllProducts(@RequestParam(required = false) String categorie) {
        try {
            List<Produit> produits = new ArrayList<>();

            if (categorie == null) {
                service.listAll().forEach(produits::add); // Récupère tous les produits via le service et les ajoute à la liste
            } else {
                service.listProduitsParCategorie(categorie).forEach(produits::add); // Récupère les produits par catégorie et les ajoute à la liste
            }
        //  Utilisation de ResponseEntity pour contrôler les détails de la réponse HTTP
            if (produits.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Si la liste est vide, retourne un code de statut NO_CONTENT
            }

            return new ResponseEntity<>(produits, HttpStatus.OK); // Retourne la liste de produits avec un code de statut OK
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); // En cas d'erreur, retourne un code de statut INTERNAL_SERVER_ERROR
        }
    }
*/
// 3eme version :
/*
 expressions lambda avec la syntaxe de la fonction flèche (->) 
 pour ajouter les produits à la liste produits à l'intérieur des méthodes forEach.
  Cette syntaxe est similaire à l'utilisation des références de méthodes mais plus concise, 
 et elle spécifie le comportement à exécuter pour 
 chaque élément de la liste retournée par les méthodes du service.
*/
/*
@GetMapping("/products")
public ResponseEntity<List<Produit>> getAllProducts(@RequestParam(required = false) String categorie) {
    try {
        List<Produit> produits = new ArrayList<>();

        if (categorie == null) {
            service.listAll().forEach(produit -> produits.add(produit)); // Récupère tous les produits via le service et les ajoute à la liste
        } else {
            service.listProduitsParCategorie(categorie).forEach(produit -> produits.add(produit)); // Récupère les produits par catégorie et les ajoute à la liste
        }

        // Utilisation de ResponseEntity pour contrôler les détails de la réponse HTTP
        if (produits.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Retourne un code 204 NO_CONTENT si la liste est vide
        }

        return new ResponseEntity<>(produits, HttpStatus.OK); // Retourne la liste de produits avec un code 200 OK
    } catch (Exception e) {
        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); // Retourne un code 500 INTERNAL_SERVER_ERROR en cas d'erreur
    }
}
*/

    @PostMapping("/products")
    public ResponseEntity<Produit> createProduct(@RequestBody Produit produit) {
        try {
            String nom = produit.getCategorie().getNom();
            int categorieId;
            System.out.println(" produit.getCategorie() :  " + nom);
            switch (nom){
                case "FROMAGES" : categorieId =1;
                break;
                case "PAINS" : categorieId =2;
                    break;
                case "LEGUMES" : categorieId =3;
                    break;
                case "VIANDES" : categorieId =4;
                    break;
                default: categorieId= 5;
                break;
            }
            System.out.println(" produit.getCategorie() :  " + produit.getCategorie().getNom());
            System.out.println(" produit.getCategorie().getId() :  " +produit.getCategorie().getId());
            Categorie categorie = entityManager.find(Categorie.class, categorieId); // Remplacez "categorieId" par l'identifiant de la catégorie souhaitée
            produit.setCategorie(categorie);
            //Produit(String nom, double prix, String description, String url_photo, Date derniere_maj, Categorie categorie)
            Produit _product = repo.save(produit);
            System.out.println(" probleme ");
            return new ResponseEntity<>(_product, HttpStatus.CREATED);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<Produit> updateProduct(@PathVariable("id") long id, @RequestBody Produit product) {
        System.out.println("id :" +id);
        Optional<Produit> productData = repo.findById(id);
System.out.println("productData :" +productData);
        if (productData.isPresent()) {
            Produit _product = productData.get();
            _product.setNom(product.getNom());
            _product.setCategorie(product.getCategorie());
            _product.setPrix(product.getPrix());
            return new ResponseEntity<>(service.save(_product), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/products/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable("id") long id) {
        try {
            repo.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

@GetMapping("/products/id/{id}")
public ResponseEntity<Produit> findProduct(@PathVariable("id") long id) {
    try {
        Optional<Produit> productOptional = repo.findById(id);
        if (productOptional.isPresent()) {
            Produit product = productOptional.get();
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.notFound().build();
        }
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}

    @GetMapping("/products/categorie/{nom}")
    public ResponseEntity<List<Produit>> findProductsByCategorie(@PathVariable("nom") String nom) {
        try {
            List<Produit> produits = repo.getProduitsByCategorie(nom);
            if (!produits.isEmpty()) {
                return ResponseEntity.ok(produits);
            } else {
                return ResponseEntity.noContent().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
