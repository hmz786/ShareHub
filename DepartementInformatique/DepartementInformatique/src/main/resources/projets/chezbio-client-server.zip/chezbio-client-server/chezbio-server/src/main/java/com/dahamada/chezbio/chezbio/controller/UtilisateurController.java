package com.dahamada.chezbio.chezbio.controller;

import com.dahamada.chezbio.chezbio.entities.Role;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import com.dahamada.chezbio.chezbio.exportpdf.UtilisateurPdfExporter;
import com.dahamada.chezbio.chezbio.service.UtilisateurNotFoundException;
import com.dahamada.chezbio.chezbio.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
public class UtilisateurController {
    @Autowired
    UtilisateurService service;
    @GetMapping("/utilisateurs")
    public String afficherUtilisateur(Model model){
        List<Utilisateur> listUtilisateurs = service.listAll();
        model.addAttribute("listUtilisateurs",listUtilisateurs);
        return "utilisateurs";
    }

    @GetMapping("utilisateurs/new")
    public String afficherFormulaireUtilisateur(Model model){
        List<Role> listRoles = service.listRoles();
        Utilisateur utilisateur = new Utilisateur();
        utilisateur.setActive(true);
        model.addAttribute("utilisateur", utilisateur);
        model.addAttribute("listRoles", listRoles);
        model.addAttribute("pageTitle", "Ajouter un nouveau utilisateur");
        return "utilisateurs_form";
    }
    @PostMapping("/utilisateurs/save")
    public String ajouterUtilisateur(Utilisateur utilisateur, RedirectAttributes redirectAttributes, @RequestParam("fileImage") MultipartFile multipartFile){

        //L'annotation  @RequestParam("fileImage") permet de gérer la valeur passé en paramètre
        //L'interface MultipartFile permet de representer un fichier recu dans une requête en plusieurs parties
        // Ici on recoit la photo, les valeurs des champs
        // La méthode getOriginalFilename() retourne le contenu du fichier
        String chemin = multipartFile.getOriginalFilename();
        System.out.println("chemin : " + chemin);
        // La méthode cleanPath permet de normaliser le chemin en supprimant les séquences indésirables
        String fileName = StringUtils.cleanPath(chemin);
        System.out.println("fileName : " + fileName);
        utilisateur.setPhoto(fileName);
        //L'interface RedirectAttributes permet d'ajouter des attributs flash stockés en session
        // jusqu'au prochaine requete de l'utilisateur.
        //Ces attributs sont mémoirisés temporairement dans le contexte d'exécution
        // le temps d'une redirection

        redirectAttributes.addFlashAttribute("message", "L'utilisateur a été  ajouté avec succès.");



        service.save(utilisateur);
        //L'utilisation du préfixe redirect  dans une requete POST permet de rediger le navigateur
        // vers une nouvelle adresse en oubliant la requête précédente évitant ainsi à l'utilisateur
        // la possibilité de la réemettre
        // pour éviter que la réémission de la requête n’aura pas des effets de bord sur le serveur
        return "redirect:/utilisateurs";
    }

    @GetMapping("/utilisateurs/edit/{id}")
    public String MettreAjourUtilisateur(@PathVariable(name = "id") Integer id, RedirectAttributes redirectAttributes, Model model) {


        try {
            Utilisateur utilisateur = service.get(id);
            List<Role> listRoles = service.listRoles();
            model.addAttribute("utilisateur", utilisateur);
            model.addAttribute("pageTitle", "Editer Utilisateur (ID: " + id + ")");

            model.addAttribute("listRoles", listRoles);
            return "utilisateurs_form";
        } catch (UtilisateurNotFoundException e) {
            //  e.printStackTrace();
            // redirectAttributes.addFlashAttribute("message", e.getMessage());
            redirectAttributes.addFlashAttribute("message", "On ne peut pas trouver un utilisateur avec l'id " + id);
            return "redirect:/utilisateurs";
        }


    }

    @GetMapping("/utilisateurs/delete/{id}")
    public String supprimerUtilisateur(@PathVariable(name = "id") Integer id,
                                       Model model,
                                       RedirectAttributes redirectAttributes) {
        try {
            service.delete(id);;
            redirectAttributes.addFlashAttribute("message",
                    "L'utilisateur ID " + id + " a été supprimé avec succès ");
        } catch (UtilisateurNotFoundException ex) {
            redirectAttributes.addFlashAttribute("message", "On ne peut pas trouver un utilisateur avec l'id " + id);
        }

        return "redirect:/utilisateurs";
    }


    @GetMapping("/utilisateurs/{id}/active/{status}")
    public String mettreAjourStatusActiveUtilisateur(@PathVariable("id") Integer id,
                                                     @PathVariable("status") boolean active, RedirectAttributes redirectAttributes) {
        service.updateActiveStatus(id, active);
        String status = active ? "active" : "desactive";
        String message = "L'utilisateur ID " + id + " a son status " + status;
        redirectAttributes.addFlashAttribute("message", message);

        return "redirect:/utilisateurs";
    }

    @GetMapping("/utilisateurs/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws IOException, IOException {
        List<Utilisateur> listUsers = service.listAll();

        UtilisateurPdfExporter exporter = new UtilisateurPdfExporter();
        exporter.export(listUsers, response);
    }

    @GetMapping("/rechercher/utilisateurs")
    public String rechercherUtilisateur(
                                        Model model, @Param("keyword") String keyword)
    {
        List<Utilisateur> listUtilisateurs = service.rechercherUtilisateur(keyword);

        model.addAttribute("listUtilisateurs",listUtilisateurs);
        model.addAttribute("keyword", keyword);
        return "utilisateurs";
    }


}
