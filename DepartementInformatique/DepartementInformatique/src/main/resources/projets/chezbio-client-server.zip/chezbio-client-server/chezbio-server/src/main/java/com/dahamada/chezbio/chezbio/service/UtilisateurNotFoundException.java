package com.dahamada.chezbio.chezbio.service;

public class UtilisateurNotFoundException extends Exception{
    public UtilisateurNotFoundException(String s) {
    }
}
