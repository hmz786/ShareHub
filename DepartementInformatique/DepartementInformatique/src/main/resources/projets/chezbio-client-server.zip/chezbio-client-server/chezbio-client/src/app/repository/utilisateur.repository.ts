import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utilisateur } from '../models/utilisateur.model';
import { Observable, catchError, shareReplay, throwError } from 'rxjs';
import { Role } from '../models/role.model';

@Injectable({
  providedIn: 'root'
})
export class UtilisateurRepository {
   // URL de l'API pour les utilisateurs
  // private apiUrl = "http://localhost:3000/utilisateurs";
  private apiUrl = "http://localhost:8080/api/utilisateurs";
   // Constructeur du service, injecte HttpClient
   // HttpClient est un service Angular qui permet d'effectuer des requêtes HTTP.
   constructor(private http: HttpClient) { }

   // Obtient la liste des utilisateurs de manière asynchrone
   // Observable est une classe du module rxjs qui représente une séquence d'événements asynchrones.
   // Dans ce contexte, il est utilisé pour gérer la réponse asynchrone de la requête HTTP.
   getUtilisateurs(): Observable<Utilisateur[]> {
     return this.http.get<Utilisateur[]>(this.apiUrl);
   }

   // Supprime un utilisateur en envoyant une requête DELETE avec son ID
   deleteUtilisateur(id: number | undefined): Observable<Utilisateur> {
     return this.http.delete<Utilisateur>(`${this.apiUrl}/${id}`);
   }


   // Sauvegarde un nouvel utilisateur en envoyant une requête POST avec l'utilisateur

   /*
   saveUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {

     const utilisantJson =
     {

      "email": "testTest@gmail.com",
      "password": "test23",
      "nom": "Test",
      "prenom": "Test",
      "photo": "Will Smith.png",
      "active": true,
      "roles": [
          {
              "id": 1,
              "nom": "Admin",
              "description": "Peut tout faire"
          }
      ]
  }
   ;
   console.log("utilisantJson : " +utilisantJson);
   console.log(JSON.stringify(utilisantJson));
    return this.http.post<Utilisateur>(this.apiUrl, utilisantJson);
  }
*/
/*
saveUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {
  const utilisantJson = {
      "email": "testTest@gmail.com",
      "password": "test23",
      "nom": "Test",
      "prenom": "Test",
      "photo": "Will Smith.png",
      "active": true,
      "roles": [{
          "id": 1,
          "nom": "Admin",
          "description": "Peut tout faire"
      }]
  };

  console.log('Sending HTTP request to save utilisateur...');

  // Utilisation de l'opérateur shareReplay pour éviter les multiples requêtes HTTP
  const request = this.http.post<Utilisateur>(this.apiUrl, utilisantJson).pipe(
      shareReplay(1) // Met en cache la réponse et la rejoue pour toutes les souscriptions ultérieures
  );

  request.subscribe({
    next: (response) => console.log('Utilisateur saved successfully:', response),
    error: (error) => console.error('Error saving utilisateur:', error)
});

  return request;
}
 */

saveUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {
  console.log("utilisateur : " + utilisateur);
  return this.http.post<Utilisateur>(this.apiUrl, utilisateur);
}


  /*
  saveUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {
    console.log('Sending HTTP request to save utilisateur...', utilisateur);

    // Agréger les noms des rôles sélectionnés en un seul objet
    const roles: any = {};
    utilisateur.roles?.forEach((role: Role) => {
      // @ts-ignore
      roles[role.nom] = true; // Utilisation d'une chaîne vide si role.nom est undefined
    });

    // Convertir l'objet roles en un tableau de chaînes contenant uniquement les noms des rôles
    // @ts-ignore
    utilisateur.roles = Object.keys(roles);

    console.log("utilisateur : ", utilisateur);

    // Utilisation de l'opérateur shareReplay pour éviter les multiples requêtes HTTP
    const request = this.http.post<Utilisateur>(this.apiUrl, utilisateur).pipe(
      shareReplay(1) // Met en cache la réponse et la rejoue pour toutes les souscriptions ultérieures
    );

    request.subscribe({
      next: (response) => console.log('Utilisateur saved successfully:', response),
      error: (error) => console.error('Error saving utilisateur:', error)
    });

    return request;
  }
*/
  // Met à jour un utilisateur en envoyant une requête PUT avec l'utilisateur et son ID
  /*
     updateUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {
      // Assurez-vous que les rôles sont envoyés sous forme de tableau même s'il n'y en a qu'un seul
       // Assurez-vous que les rôles ne sont pas undefined et sont sous forme de tableau
     utilisateur.roles = utilisateur.roles ? Array.isArray(utilisateur.roles) ? utilisateur.roles : [utilisateur.roles] : [];
          console.log(" utilisateur.roles : " +  utilisateur.roles);
      // Construire l'URL de la requête PUT en utilisant l'identifiant de l'utilisateur
      const url = `${this.apiUrl}/${utilisateur.id}`;

      // Construire le corps de la requête en transformant l'objet utilisateur en chaîne JSON
      const body = JSON.stringify(utilisateur);
      console.log("body : " + body);
      // Définir les en-têtes de la requête pour spécifier le type de contenu JSON
      const headers = new HttpHeaders().set('Content-Type', 'application/json');

      // Envoyer la requête PUT au backend avec l'URL, le corps et les en-têtes appropriés
      return this.http.put<Utilisateur>(url, body, { headers: headers });
    }
*/

  updateUtilisateur(utilisateur: Utilisateur): Observable<Utilisateur> {

    // Envoyer la requête PUT au backend avec l'URL, le corps et les en-têtes appropriés
    return this.http.put<Utilisateur>(`${this.apiUrl}/${utilisateur.id}`, utilisateur);
  }

  /**
 * Met à jour le statut de disponibilité d'un utilisateur dans la base de données.
 * @param id Identifiant de l'utilisateur à mettre à jour.
 * @param disponible Nouveau statut de disponibilité de l'utilisateur.
 * @returns Un observable contenant l'utilisateur mis à jour.
 */
/*
updateUtilisateurStatus(id: number | undefined, disponible: boolean): Observable<Utilisateur> {
  // Crée un objet contenant le nouveau statut de disponibilité
  const body = { disponible: disponible };
  // Effectue une requête POST pour mettre à jour le statut de l'utilisateur
  return this.http.post<Utilisateur>(`${this.apiUrl}/${id}`, body);
}
*/
/*
updateStatus(id: number | undefined, active: boolean): Observable<Utilisateur> {
  const body = { active: active };
  // Assurez-vous que l'URL est correctement construite
  return this.http.post<Utilisateur>(`${this.apiUrl}/${id}/status`, body);
}
*/
updateStatus(id: number | undefined, active: boolean): Observable<Utilisateur> {
  // Construire le corps de la requête avec le paramètre 'active'
  const body = new HttpParams().set('active', active.toString());

  // Envoyer la requête POST au backend
  return this.http.post<Utilisateur>(`${this.apiUrl}/${id}/status`, body);
}



/*
updateStatus(id: number | undefined, active: boolean): Observable<Utilisateur> {
  const body = { active: active };
  // Assurez-vous que l'URL est correctement construite
  return this.http.post<Utilisateur>(`${this.apiUrl}/utilisateurs/${id}/status`, body).pipe(
    catchError((error: HttpErrorResponse) => {
      // Gérer l'erreur ici
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        // Erreur côté client
        errorMessage = `Une erreur est survenue : ${error.error.message}`;
      } else {
        // Erreur côté serveur
        errorMessage = `Code d'erreur : ${error.status}, Message : ${error.message}`;
      }
      console.error(errorMessage);
      // Retourne un observable avec l'erreur
      return throwError(errorMessage);
    })
  );
}
*/



}
