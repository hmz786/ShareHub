import { Component, Input } from '@angular/core';
import { Utilisateur } from '../../models/utilisateur.model';

@Component({
  selector: 'app-photo-utilisateur',
  template: `
  <td>
  <img class="utilisateur-image" [src]="'assets/images/utilisateurs/' + utilisateur.photo">
</td>
  `,
  styles: ``
})
export class PhotoUtilisateurComponent {
 // @Input: Propriété permettant au parent de passer des données à l'enfant
 @Input() utilisateur!: Utilisateur;
}
