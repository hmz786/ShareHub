import { Component } from '@angular/core';
import { Utilisateur } from '../../models/utilisateur.model';
import { UtilisateurService } from '../../services/utilisateur.service';

@Component({
  selector: 'app-utilisateur',
  templateUrl: './utilisateur.component.html',
  styles: ``
})
export class UtilisateurComponent {

  public searchTerm: string = '';
   public roleSelectionnee: string | null = null; // Mise à jour du type de données pour éviter l'erreur
  
   // Constructeur du composant, injecte les services nécessaires
   constructor(private service: UtilisateurService) {}
   
   get utilisateurs(): Utilisateur[] {
     return this.service.getUtilisateurs(this.roleSelectionnee);
   } 
 
   // Méthode appelée lors de la suppression d'un utilisateur
    // @Output: Méthode appelée lors de la suppression d'un utilisateur
   deleteUtilisateur(id: number) {
     console.log('deleteUtilisateur called with ID:', id);
     this.service.deleteUtilisateur(id);
   }
 
}
