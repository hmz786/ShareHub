package com.dahamada.chezbio.chezbio.controller;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.service.CategorieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class CategorieController {
    @Autowired
    private CategorieService categorieService;

    @GetMapping("/categories")
    public String afficherCategories(Model model){
        List<Categorie> listeCategories = categorieService.listAll();
        model.addAttribute("listeCategories",listeCategories);

        return "categories";
    }

    @GetMapping("/categories/new")
    public String afficherFormulaireCategories(Model model){
        // List<Categorie> listeCategories = repo.findAll();
        model.addAttribute("categorie",new Categorie());
        return "categories_form";
    }

    @PostMapping("/categories/save")
    public String ajouterCategories(Categorie categorie, RedirectAttributes redirectAttributes){
        redirectAttributes.addFlashAttribute("message", "La catégorie a été  ajouté avec succès.");
        categorieService.save(categorie);
        return "redirect:/categories";
    }


    @GetMapping("/categorie/{id}")
    public String afficherProduitParCategorie(Model model,@PathVariable int id){
        List<Produit> listProduitByCategorie = categorieService.listProduitByCategorie(id);
        for (Produit produit : listProduitByCategorie) {
            System.out.println("Nom : " + produit.getNom());
            System.out.println("Prix : " + produit.getPrix());
            System.out.println("URL : " + produit.getUrl_photo());
        }
        model.addAttribute("listProduitByCategorie",listProduitByCategorie);
        return "produits_categorie";
    }


}
