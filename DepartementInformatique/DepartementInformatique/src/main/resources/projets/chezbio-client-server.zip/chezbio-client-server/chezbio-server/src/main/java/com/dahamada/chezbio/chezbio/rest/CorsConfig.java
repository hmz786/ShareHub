package com.dahamada.chezbio.chezbio.rest;

/*
Ce code, classe représente une configuration CORS (Cross-Origin Resource Sharing)
pour une application web développée avec Spring Boot.
CORS est un mécanisme de sécurité côté client qui permet à un serveur
 de définir quels domaines externes sont autorisés à accéder à ses ressources.

*/

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration  // Cette annotation marque la classe CorsConfig comme une configuration Spring.

// Cette classe implémente l'interface WebMvcConfigurer,
//ce qui permet de personnaliser la configuration de Spring MVC
//pour gérer les requêtes CORS
public class CorsConfig implements WebMvcConfigurer {
    //  Cette méthode est appelée pour ajouter des règles de mapping CORS
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        //  Cela spécifie le mapping pour lequel la configuration CORS s'applique.
        //Ici, /** indique que toutes les URL de l'application sont concernées.
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:4200") // Autoriser les requêtes provenant de votre application Angular
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Autoriser les méthodes HTTP nécessaires
                .allowedHeaders("*") // Autoriser tous les en-têtes
                .allowCredentials(true); // Autoriser les cookies et les en-têtes d'autorisation
    }
}
