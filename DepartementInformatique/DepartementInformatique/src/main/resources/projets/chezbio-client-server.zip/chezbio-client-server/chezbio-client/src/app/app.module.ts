import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AccueilComponent } from './components/accueil/accueil.component';


import { UtilisateurComponent } from './components/utilisateur/utilisateur.component';
import { TableUtilisateurComponent } from './components/table-utilisateur/table-utilisateur.component';
import { PhotoUtilisateurComponent } from './components/photo-utilisateur/photo-utilisateur.component';
import { FormUtilisateurComponent } from './components/form-utilisateur/form-utilisateur.component';






@NgModule({
  declarations: [
    AppComponent,
    AccueilComponent,
 
  
    UtilisateurComponent,
    TableUtilisateurComponent,
    PhotoUtilisateurComponent,
    FormUtilisateurComponent,
    
  
  
   
 
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
