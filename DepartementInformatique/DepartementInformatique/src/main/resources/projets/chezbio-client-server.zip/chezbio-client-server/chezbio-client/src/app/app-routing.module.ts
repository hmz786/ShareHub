import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccueilComponent } from './components/accueil/accueil.component';


import { UtilisateurComponent } from './components/utilisateur/utilisateur.component';
import { FormUtilisateurComponent } from './components/form-utilisateur/form-utilisateur.component';


const routes: Routes = [
  { path: '', component: AccueilComponent},

  { path: 'does', redirectTo: '/formProduit/create', pathMatch: 'prefix' },
  { path: 'utilisateur', component: UtilisateurComponent },
  { path: 'formUtilisateur/create', component: FormUtilisateurComponent },
  { path: 'formUtilisateur/:mode/:id', component: FormUtilisateurComponent }


];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
