package com.dahamada.chezbio.chezbio;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import com.dahamada.chezbio.chezbio.repos.ProduitRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class ProduitRepositoryTests {
    @Autowired
    private ProduitRepository repo;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testCreateProduit(){
        Categorie categorie = entityManager.find(Categorie.class, 1);
        assertThat(categorie).isNotNull();
        assertThat(categorie.getId()).isGreaterThan(0);

        System.out.println("categorie : " +categorie);

        Produit produit = new Produit();
        produit.setNom("GRUYERE");
        produit.setPrix(2.50);
        produit.setDescription("plaquette");
        produit.setUrl_photo("GRUYERE.png");
        produit.setDerniere_maj(new Date());
        produit.setCategorie(categorie);
        Produit produitEntregistre = repo.save(produit);
        assertThat(produitEntregistre).isNotNull();
        assertThat(produitEntregistre.getId()).isGreaterThan(0);



    }

    @Test
    public void testCreateRestProduit(){
        Categorie categorie1 = entityManager.find(Categorie.class, 1);
        assertThat(categorie1).isNotNull();
        assertThat(categorie1.getId()).isGreaterThan(0);

        System.out.println("categorie : " +categorie1);

        Produit produit1 = new Produit();
        produit1.setNom("LAIT");
        produit1.setPrix(1.20);
        produit1.setDescription("pack");
        produit1.setUrl_photo("LAIT.png");
        produit1.setDerniere_maj(new Date());
        produit1.setCategorie(categorie1);
        repo.save(produit1);

        Produit produit2 = new Produit();
        produit2.setNom("OEUFS");
        produit2.setPrix(2.30);
        produit2.setDescription("6");
        produit2.setUrl_photo("OEUFS.png");
        produit2.setDerniere_maj(new Date());
        produit2.setCategorie(categorie1);
        repo.save(produit2);

        Categorie categorie2 = entityManager.find(Categorie.class, 2);
        assertThat(categorie1).isNotNull();
        assertThat(categorie1.getId()).isGreaterThan(0);

        System.out.println("categorie2 : " +categorie2);
        Produit produit3 = new Produit();
        produit3.setNom("PIZZA");
        produit3.setPrix(2.80);
        produit3.setDescription("unite");
        produit3.setUrl_photo("PIZZA.png");
        produit3.setDerniere_maj(new Date());
        produit3.setCategorie(categorie2);
        repo.save(produit3);

        Produit produit4 = new Produit();
        produit4.setNom("COOKIES");
        produit4.setPrix(0.50);
        produit4.setDescription("pièce");
        produit4.setUrl_photo("COOKIES.png");
        produit4.setDerniere_maj(new Date());
        produit4.setCategorie(categorie2);
        repo.save(produit4);



        Categorie categorie3 = entityManager.find(Categorie.class, 3);
        assertThat(categorie3).isNotNull();
        assertThat(categorie3.getId()).isGreaterThan(0);

        System.out.println("categorie3 : " +categorie3);


        Produit produit5 = new Produit();
        produit5.setNom("RADIS");
        produit5.setPrix(4);
        produit5.setDescription("kg");
        produit5.setUrl_photo("RADIS.png");
        produit5.setDerniere_maj(new Date());
        produit5.setCategorie(categorie3);
        repo.save(produit5);

        Produit produit6 = new Produit();
        produit6.setNom("CAROTTES");
        produit6.setPrix(3.70);
        produit6.setDescription("kg");
        produit6.setUrl_photo("CAROTTES.png");
        produit6.setDerniere_maj(new Date());
        produit6.setCategorie(categorie3);
        repo.save(produit6);


        Categorie categorie4 = entityManager.find(Categorie.class, 4);
        assertThat(categorie4).isNotNull();
        assertThat(categorie4.getId()).isGreaterThan(0);

        System.out.println("categorie4 : " +categorie4);


        Produit produit7 = new Produit();
        produit7.setNom("JAMBON");
        produit7.setPrix(8.50);
        produit7.setDescription("pièce");
        produit7.setUrl_photo("JAMBON.png");
        produit7.setDerniere_maj(new Date());
        produit7.setCategorie(categorie4);
        repo.save(produit7);

        Produit produit8 = new Produit();
        produit8.setNom("POULET");
        produit8.setPrix(12.50);
        produit8.setDescription("kg");
        produit8.setUrl_photo("POULET.png");
        produit8.setDerniere_maj(new Date());
        produit8.setCategorie(categorie4);
        repo.save(produit8);

    }

    @Test
    public void testGetProduitByCategorie() {
        //On passe en paramètre un email existant
        String categorie = "FROMAGES";
        //On retourne l'utilisateur avec qui a l'email
        List<Produit>  produitList = repo.getProduitsByCategorie(categorie);
        for(Produit p:produitList){
            System.out.println(p.toString());
        }
        //On vérifie si c'est différent de null
        assertThat(produitList).isNotNull();
    }
}
