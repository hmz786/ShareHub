package com.dahamada.chezbio.chezbio;

import com.dahamada.chezbio.chezbio.entities.Role;
import com.dahamada.chezbio.chezbio.entities.Utilisateur;
import com.dahamada.chezbio.chezbio.repos.UtilisateurRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

//@DataJpaTest(showSql = false)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class UtilisateurRepositoryTests {
    @Autowired
    private UtilisateurRepository repo;
    @Autowired
    private TestEntityManager entityManager;
    @Test
    public void testCreateUtilisateur(){
        Role roleAdmin = entityManager.find(Role.class, 1);
        Utilisateur userKarim = new Utilisateur("Alain", "Karim", "karim10@gmail.com", "karim123");
        userKarim.ajouter(roleAdmin);
        System.out.println(" userKarim : " + userKarim);
        Utilisateur savedUser = repo.save(userKarim);

        assertThat(savedUser.getId()).isGreaterThan(0);

    }
    @Test
    public void testCreateNewUtilisateurAvecDeuxRoles() {
        Utilisateur userRavi = new Utilisateur("Pierre", "Jean", "jean@gmail.com", "Jean123");
        Role roleEditor = new Role(3);
        Role roleAssistant = new Role(5);

        userRavi.ajouter(roleEditor);
        userRavi.ajouter(roleAssistant);

        Utilisateur savedUser = repo.save(userRavi);

        assertThat(savedUser.getId()).isGreaterThan(0);
    }
    @Test
    public void testListTousUtilisateur() {
        Iterable<Utilisateur> listUsers = repo.findAll();
        listUsers.forEach(utilisateur -> System.out.println(utilisateur));
        /*
        for (Utilisateur utilisateur:listUsers){
            System.out.println(utilisateur);
        }
        */

    }
    @Test
    public void testGetUtilisateurById() {
        Utilisateur utilisateur = repo.findById(1).get();
        System.out.println(utilisateur);
        assertThat(utilisateur).isNotNull();
    }

    @Test
    public void testUpdateUtilisateurDetails() {
        Utilisateur utilisateur = repo.findById(1).get();
        utilisateur.setActive(true);
        utilisateur.setEmail("alain@gmail.com");

        repo.save(utilisateur);
    }

    @Test
    public void testUpdateUtilisateurRoles() {
        Utilisateur userRavi = repo.findById(2).get();
        Role roleEditor = new Role(3);
        Role roleSalesperson = new Role(2);

        userRavi.getRoles().remove(roleEditor);
        userRavi.ajouter(roleSalesperson);

        repo.save(userRavi);
    }

    @Test
    public void testDeleteUtilisateur() {
        Integer userId = 2;
        repo.deleteById(userId);

    }
    @Test
    public void testGetUserByEmail() {
        //On passe en paramètre un email existant
        String email = "cat2@gmail.com";
        //On retourne l'utilisateur avec qui a l'email
        Utilisateur user = repo.getUtilisateurByEmail(email);
        //On vérifie si c'est différent de null
        assertThat(user).isNotNull();
    }

    @Test
    public void testCountById() {
        Integer id = 1;
        Long countById = repo.countById(id);

        assertThat(countById).isNotNull().isGreaterThan(0);
    }

    @Test
    public void testDisableUser() {
        Integer id = 1;
        repo.updateActiveStatus(id, false);

    }

    @Test
    public void testEnableUser() {
        Integer id = 3;
        repo.updateActiveStatus(id, true);

    }



}
