package com.dahamada.chezbio.chezbio.controller;

import com.dahamada.chezbio.chezbio.entities.Categorie;
import com.dahamada.chezbio.chezbio.entities.Produit;
import com.dahamada.chezbio.chezbio.service.CategorieService;
import com.dahamada.chezbio.chezbio.service.ProduitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class ProduitController {
    @Autowired
    private ProduitService produitService;
    @Autowired
    private CategorieService categorieService;
    @GetMapping("/produits")
    public String afficherProduits(Model model){

        List<Produit> listeProduits = produitService.listAll();
        Produit produit = new Produit();
        model.addAttribute("produit",produit);
        model.addAttribute("listeProduits",listeProduits);
        return "produits";
    }
    @GetMapping("/produits/new")
    public String afficherFormulaireProduit(Model model){
        List<Categorie> listeCategories = categorieService.listAll();
        Produit produit = new Produit();
        model.addAttribute("produit",produit);
        model.addAttribute("listeCategories", listeCategories);

        return "produits_form";
    }

    @PostMapping("/produits/save")
    public String ajouterProduit(Produit produit, RedirectAttributes redirectAttributes, @RequestParam("fileImage") MultipartFile multipartFile){
        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        System.out.println("fileName " + fileName);
        produit.setUrl_photo(fileName);

        redirectAttributes.addFlashAttribute("message", "Le produit a été  ajouté avec succès.");
        produitService.save(produit);
        return "redirect:/produits";
    }
}
